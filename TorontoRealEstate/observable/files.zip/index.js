export {default} from "./1640f0aa65e51ed0@3009.js";
